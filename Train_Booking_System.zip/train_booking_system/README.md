# RailNova — Train Booking System

A ready-to-submit static train booking system built with HTML and CSS.

## Run
1. Extract the ZIP file.
2. Open `index.html` in Chrome/Edge/Firefox.
3. Choose **Passenger Portal** or **Admin Panel**.

## Main pages
- `client-side/index.html` — Passenger dashboard
- `client-side/book.html` — Train search
- `client-side/trains.html` — Available trains
- `client-side/payment.html` — Payment demo
- `client-side/confirmation.html` — Booking confirmation
- `client-side/tickets.html` — My tickets
- `client-side/profile.html` — Passenger profile
- `admin-side/index.html` — Admin dashboard
- `admin-side/trains.html` — Train management
- `admin-side/bookings.html` — Booking management
- `admin-side/reports.html` — Reports
- `admin-side/users.html` — Customer management
- `admin-side/settings.html` — System settings
- `assets/style.css` — Shared responsive styling

## Note
This is a front-end/demo project. Payment, database, authentication and real railway APIs are simulated with static HTML interactions.
